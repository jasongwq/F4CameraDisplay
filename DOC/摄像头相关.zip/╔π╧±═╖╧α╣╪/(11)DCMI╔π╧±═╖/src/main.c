#include "main.h"

int main(void)
{
	Key_Init();
	LED_Init();
	LCD_Init();
	LCD_String(20,20,"DCMI Camera demo",RED);
	if(OV7670_Init())
	{
		LCD_String(20,50,"OV7670 init failed!",RED);
		while(1)
		{
			delay_ms(300);
			LEDTog(LED4);
		}
	}
	delay_ms(1000);
	LCD_Clear(BLUE);
	Cam_Start();
  	while(1)
	{
		delay_ms(500);
		LEDTog(LED1);	
	}
}


